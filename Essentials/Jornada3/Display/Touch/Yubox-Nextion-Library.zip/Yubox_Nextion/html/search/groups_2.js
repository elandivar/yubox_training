var searchData=
[
  ['nextion_20component',['Nextion Component',['../group___component.html',1,'']]]
];
