# yubox-framework
Librería que consolida varias necesidades comunes a todos los proyectos basados en YUBOX ESP32 para IoT.

Uso
---

Se hace ckeckout del proyecto en la ruta de librerías de Arduino. Por ejemplo: $HOME/Arduino/libraries

Luego se pude ejercitar con el ejemplo de la capeta examples
